jQuery(document).ready(function($) {
	$('.toggle-menu').jPushMenu();
}); 